from __future__ import annotations
import ast
from datetime import datetime
import json
import logging
from pathlib import Path
import re
from functools import lru_cache
from typing import Optional, Dict, Any, Tuple
from app.config import settings
from app.models import DocumentStatusCode, ShippingInstruction


_llm_pipeline = None
logger = logging.getLogger(__name__)
_system_prompt = (
    "You are a shipping instruction document parser. "
    "Extract structured data from the OCR text of a shipping instruction / bill of lading document. "
    "Return ONLY valid JSON matching the provided schema. "
    "If a field is not present in the document, set it to null. "
    "Do not fabricate data. Map field names as follows: "
    "shipping_instruction_reference, document_status_code, shipping_instruction_date_time, "
    "carrier_booking_reference, transport_document_type, freight_payment_term_code, issue_date, "
    "place_of_issue (with un_location_code, location_name), export_declaration_number, "
    "service_contract_reference, parties (list of party with party_role_code SHI/CON/NTF, party_id, "
    "party_name, address with street/city/postal_code/country_code, contact_details with name/email/phone_number, "
    "same_as_consignee), transport_plans (leg_sequence_number, transport_mode, port_of_loading, port_of_discharge, "
    "place_of_receipt, place_of_delivery, carrier_voyage_number, vessel_imo_number), "
    "equipment_list (equipment_reference, iso_equipment_code, is_shipper_owned, cargo_gross_weight, "
    "verified_gross_mass, seals, tare_weight), cargo_items (package_quantity, package_kind_code, "
    "description_of_goods, shipping_marks, commodity_code, weight, volume, equipment_references, "
    "dangerous_goods_list), document_references, customs_information, remarks. "
    "Apply these mapping rules strictly: "
    "--- PARTIES --- "
    "SHIPPER=exporter/seller. CONSIGNEE=receiver/buyer. NOTIFY PARTY must be a company or person name, "
    "never a reference number, export code, or file number. "
    "Carrier headquarters address in the document letterhead (e.g. 'Hapag-Lloyd, Hamburg') is NOT the shipper "
    "address; shipper city/country come from the SHIPPER block only. "
    "--- REFERENCES --- "
    "shipping_instruction_reference: only SI No, SI Reference, Talimat No. "
    "Never put B/L No, container number, port name, or customs declaration (DU-E) here. If absent, set null. "
    "carrier_booking_reference: only Booking No, BKG Ref, Rezervasyon No. Never put B/L No here. "
    "B/L numbers go in document_references with type_code='BL'. "
    "--- LOCATIONS --- "
    "Free-text port and place names belong in location_name; only populate un_location_code when the source "
    "contains a valid five-character UN/LOCODE. POL means port of loading and POD means port of discharge. "
    "Clean OCR artifacts from port names. If a port name has a random prefix before a known city "
    "(e.g. 'TCEGE ALIAGA' -> 'ALIAGA', 'COP RIO DE JANEIRO' -> 'RIO DE JANEIRO'), "
    "keep only the city/port name. "
    "Only populate place_of_issue when the document explicitly labels a place of issue; V.DAIRESI, VERGI DAIRESI, "
    "and TAX OFFICE are tax-office labels and must never become place_of_issue. "
    "--- VESSEL --- "
    "vessel_imo_number is a 7-digit IMO number. A vessel name (e.g. 'JAZAN') is NOT an IMO number. "
    "--- WEIGHTS --- "
    "Values marked KG/KGM are weights; values marked M3/CBM are volumes. Gross "
    "weight belongs in equipment cargo_gross_weight and NET/net weight belongs in cargo_items.weight. "
    "When OCR shows BRUT and NET together (e.g. 'BRUT:26.080,00 KG- NET: 24.776,00 KG'), "
    "BRUT=gross=cargo_gross_weight, NET=net=cargo_items.weight. Never put gross in cargo_items. "
    "Parse European-formatted quantities: 26.080,00 -> 26080.00, 28,16 -> 28.16, 24.776,00 -> 24776.00. "
    "--- CONTACT --- "
    "A contact name must be a person's name, never a telephone number or label. "
    "If the OCR shows 'TELEPHONE:05325400708', put '05325400708' in phone_number and leave name null. "
    "Do not put 'TELEPHONE:' or the phone number in the name field. "
    "--- TAX --- "
    "For a shipper, labels such as V.NO, VKN, VERGI NO, TAX ID, CPF, CNPJ, and VAT NO map to that party's party_id. "
    "Never copy party_name into party_id when an explicit tax or party identifier label is absent. "
    "On a comma-separated SHIPPER or CONSIGNEE line, party_name "
    "contains only the company or person before the first comma; city and two-letter country components belong in "
    "address. "
    "--- DATES --- "
    "ISSUE DATE, DATE OF ISSUE, DATE, and TARIH map to issue_date. "
    "Populate shipping_instruction_date_time only when the source "
    "explicitly identifies an instruction date-time or includes a time. "
    "--- CARGO --- "
    "description_of_goods contains only the goods "
    "description and must exclude leading package quantities and package-kind words such as PALLETS, CARTONS, BOXES, "
    "or CRATES, and must exclude wood packaging statements, marks prefixes, and freight clauses. "
    "Equipment/container references normally contain four letters "
    "followed by seven digits; preserve them in equipment_reference and link matching cargo equipment references. "
    "Preserve company names, personal names, "
    "addresses, identifiers, codes, port names, and numeric values exactly as found in the source."
)

_language_names = {
    "auto": "mixed Turkish and English",
    "tr": "Turkish",
    "en": "English",
}

_STAGE1_SYSTEM_PROMPT = (
    "Sen bir konsimento belgesi ayristiricisin. "
    "OCR metninden SADECE taraflar ve belge referans bilgilerini cikar. "
    "Cikarilacak alanlar: shipping_instruction_reference, document_status_code, "
    "carrier_booking_reference, issue_date, place_of_issue, export_declaration_number, "
    "service_contract_reference, parties (SHI/CON/NTF rolleriyle; party_id, party_name, "
    "address, contact_details, same_as_consignee), document_references, customs_information, remarks. "
    "Diger tum alanlari bos (null) birak. "
    "Return ONLY valid JSON matching the provided schema. "
    "If a field is not present in the document, set it to null. Do not fabricate data. "
    "--- TARAF KURALLARI --- "
    "SHIPPER=ihracatçi/satici. CONSIGNEE=alici/ithalatçi. NOTIFY PARTY sirket veya kisi adi olmali, "
    "referans numarasi veya dosya numarasi olmamali. "
    "Antetli kagit uzerindeki tasiyici adresi (ornegin 'Hapag-Lloyd, Hamburg') SHIPPER adresi degildir. "
    "--- REFERANS KURALLARI --- "
    "shipping_instruction_reference: sadece SI No, SI Reference, Talimat No. "
    "B/L No, konteyner numarasi, liman adi girilmemeli. Yoksa null. "
    "carrier_booking_reference: sadece Booking No, BKG Ref, Rezervasyon No. B/L No buraya girilmemeli. "
    "B/L numaralari document_references icine type_code='BL' ile eklenmeli. "
    "--- TARIH KURALLARI --- "
    "ISSUE DATE, DATE OF ISSUE, DATE, TARIH -> issue_date. "
    "shipping_instruction_date_time sadece saat bilgisi de varsa doldurulmali. "
    "--- VERGI KURALLARI --- "
    "V.NO, VKN, VERGI NO, TAX ID, CPF, CNPJ, VAT NO -> party_id. "
    "party_id ile party_name ayni olmamali. "
    "--- KONUM KURALLARI --- "
    "place_of_issue sadece belge duzenleme yeri oldugunda doldurulmali. "
    "V.DAIRESI, VERGI DAIRESI, TAX OFFICE -> place_of_issue OLAMAZ. "
    "--- ILETISIM KURALLARI --- "
    "Contact name bir kisi adi olmali, telefon numarasi olmamali. "
    "'TELEPHONE:05325400708' -> phone_number='05325400708', name=null. "
    "Preserve company names, personal names, addresses, identifiers, codes, "
    "port names, and numeric values exactly as found in the source."
)

_STAGE2_SYSTEM_PROMPT = (
    "Sen bir konsimento belgesi ayristiricisin. "
    "OCR metninden SADECE lojistik ve tasima bilgilerini cikar. "
    "Cikarilacak alanlar: transport_document_type, freight_payment_term_code, "
    "transport_plans (leg_sequence_number, transport_mode, port_of_loading, port_of_discharge, "
    "place_of_receipt, place_of_delivery, carrier_voyage_number, vessel_imo_number). "
    "Diger tum alanlari bos (null) birak. "
    "Return ONLY valid JSON matching the provided schema. "
    "If a field is not present in the document, set it to null. Do not fabricate data. "
    "--- LIMAN KURALLARI --- "
    "Serbest metin liman adlari location_name alanina; UN/LOCODE sadece kaynakta "
    "5 karakterli gecerli bir kod varsa un_location_code alanina. "
    "POL = port of loading (yukleme limani), POD = port of discharge (bosaltma limani). "
    "OCR bozukluklarini liman adlarindan temizle: "
    "'TCEGE ALIAGA' -> 'ALIAGA', 'COP RIO DE JANEIRO' -> 'RIO DE JANEIRO'. "
    "--- GEMI KURALLARI --- "
    "vessel_imo_number 7 haneli IMO numarasidir. Gemi adi (ornegin 'JAZAN') IMO numarasi DEGILDIR. "
    "--- TASIMA TURU KURALLARI --- "
    "transport_document_type: B/L veya SWB. freight_payment_term_code: PPD (prepaid) veya COL (collect). "
    "FREIGHT PREPAID -> PPD, FREIGHT COLLECT -> COL. "
    "Preserve identifiers, codes, port names, and numeric values exactly as found in the source."
)

_STAGE3_SYSTEM_PROMPT = (
    "Sen bir konsimento belgesi ayristiricisin. "
    "OCR metninden SADECE konteyner ve yuk bilgilerini cikar. "
    "Cikarilacak alanlar: equipment_list (equipment_reference, iso_equipment_code, "
    "is_shipper_owned, cargo_gross_weight, verified_gross_mass, seals, tare_weight), "
    "cargo_items (package_quantity, package_kind_code, description_of_goods, "
    "shipping_marks, commodity_code, weight, volume, equipment_references, "
    "dangerous_goods_list). "
    "Diger tum alanlari bos (null) birak. "
    "Return ONLY valid JSON matching the provided schema. "
    "If a field is not present in the document, set it to null. Do not fabricate data. "
    "--- AGIRLIK KURALLARI --- "
    "KG/KGM -> agirlik, M3/CBM -> hacim. "
    "BRUT/ GROSS -> cargo_gross_weight (ekipman seviyesinde), NET -> cargo_items.weight. "
    "Avrupa formatli sayilari ayristir: 26.080,00 -> 26080.00, 28,16 -> 28.16, 24.776,00 -> 24776.00. "
    "--- KONTEYNER KURALLARI --- "
    "Konteyner referanslari genellikle 4 harf + 7 rakam formatindadir. "
    "ISO 6346 kontrol basamagini dogrula. equipment_reference alaninda sakla. "
    "--- YUK KURALLARI --- "
    "description_of_goods sadece mal aciklamasini icermeli; baslangictaki paket sayisi "
    "ve paket turu (PALLETS, CARTONS, BOXES, CRATES) cikarilmali. "
    "Ahsap ambalaj beyanlari, marks on ekleri ve navlun klozlari description_of_goods disinda tutulmali. "
    "shipping_marks icinde markalar ve referanslar yer almali. "
    "Eslesen kargo ekipman referanslari equipment_references altinda iliskilendirilmeli. "
    "Preserve identifiers, codes, measurement units, and numeric values exactly as found in the source."
)

_STAGE_FIELD_OWNERSHIP = {
    1: {
        "shipping_instruction_reference", "carrier_booking_reference",
        "shipping_instruction_date_time", "issue_date", "place_of_issue",
        "export_declaration_number", "service_contract_reference",
        "parties", "document_references", "customs_information", "remarks",
    },
    2: {
        "transport_document_type", "freight_payment_term_code",
        "transport_plans",
    },
    3: {
        "equipment_list", "cargo_items",
    },
}

_STAGE_PROMPTS = {
    1: _STAGE1_SYSTEM_PROMPT,
    2: _STAGE2_SYSTEM_PROMPT,
    3: _STAGE3_SYSTEM_PROMPT,
}


def get_llm_pipeline():
    global _llm_pipeline
    if _llm_pipeline is not None:
        return _llm_pipeline
    import openvino_genai

    model_path = Path(settings.model.model_path)
    if not model_path.exists():
        raise FileNotFoundError(
            f"Model not found at {model_path}. "
            "Run scripts/wsl_model_setup.sh or set QWEN_MODEL_PATH to an OpenVINO model."
        )
    pipeline_config = {
        "CACHE_DIR": settings.model.cache_dir,
        "CACHE_MODE": "OPTIMIZE_SIZE",
        "PERFORMANCE_HINT": "LATENCY",
    }
    weights_path = model_path / "openvino_model.bin"
    if weights_path.exists():
        pipeline_config["WEIGHTS_PATH"] = str(weights_path)
    if settings.model.kv_cache_precision:
        pipeline_config["KV_CACHE_PRECISION"] = settings.model.kv_cache_precision
    _llm_pipeline = openvino_genai.LLMPipeline(
        str(model_path), settings.model.device, pipeline_config
    )
    return _llm_pipeline


def reset_llm_pipeline() -> None:
    global _llm_pipeline
    _llm_pipeline = None


@lru_cache(maxsize=1)
def get_json_schema() -> Dict[str, Any]:
    schema = ShippingInstruction.model_json_schema()
    return schema


@lru_cache(maxsize=4)
def get_stage_schema(stage: int) -> Dict[str, Any]:
    full_schema = ShippingInstruction.model_json_schema()
    owned_fields = _STAGE_FIELD_OWNERSHIP.get(stage, set())
    if not owned_fields:
        return full_schema
    schema_copy = {
        k: v for k, v in full_schema.items() if k != "properties"
    }
    schema_copy["properties"] = {}
    for field_name in owned_fields:
        if field_name in full_schema.get("properties", {}):
            schema_copy["properties"][field_name] = full_schema["properties"][field_name]
    assert schema_copy.get("properties"), (
        f"Asama {stage} icin alan bulunamadi"
    )
    return schema_copy


def build_stage_prompt(
    ocr_text: str,
    stage: int,
    document_language: str = "en",
    output_language: str = "en",
) -> str:
    system_prompt = _STAGE_PROMPTS.get(stage, _system_prompt)
    schema = get_stage_schema(stage)
    schema_str = json.dumps(schema, indent=2, ensure_ascii=False)
    source_language = _language_names.get(document_language, "English")
    target_language = _language_names.get(output_language, "English")
    prompt = (
        f"System: {system_prompt}\n\n"
        f"The document language is {source_language}. Interpret OCR labels in that language.\n"
        f"The requested XML content language is {target_language}. Preserve all extracted values in their source "
        "language during this extraction pass. A dedicated translation pass handles descriptive content later. "
        "Never alter proper names, addresses, locations, identifiers, codes, measurement units, or enum values.\n\n"
        f"JSON Schema:\n{schema_str}\n\n"
        f"OCR Text (layout-preserved):\n{ocr_text}\n\n"
        f"Extract the shipping instruction data as JSON:"
    )
    assert ocr_text.strip(), "OCR metni bos"
    return prompt


def run_stage_inference(
    ocr_text: str,
    stage: int,
    document_language: str = "en",
    output_language: str = "en",
) -> Tuple[ShippingInstruction, str]:
    pipe = get_llm_pipeline()
    prompt = build_stage_prompt(ocr_text, stage, document_language, output_language)
    schema = get_stage_schema(stage)
    config = _build_generation_config_for_schema(schema)
    result = pipe.generate(prompt, config)
    raw_output = str(result)
    assert raw_output.strip(), f"Asama {stage} LLM ciktisi bos"
    try:
        cleaned = _extract_json(raw_output)
        data = json.loads(cleaned)
        instruction = ShippingInstruction.model_validate(data)
    except Exception:
        cleaned = _extract_json(raw_output)
        data = _parse_json_with_fallback(cleaned)
        instruction = ShippingInstruction.model_validate(data)
    return instruction, raw_output


def merge_stage_results(
    stage1: ShippingInstruction,
    stage2: ShippingInstruction,
    stage3: ShippingInstruction,
) -> ShippingInstruction:
    merged = ShippingInstruction()
    merged.document_status_code = (
        stage1.document_status_code
        or stage2.document_status_code
        or stage3.document_status_code
        or DocumentStatusCode.DRAFT
    )
    merged.shipping_instruction_date_time = (
        stage1.shipping_instruction_date_time
        or stage2.shipping_instruction_date_time
        or stage3.shipping_instruction_date_time
    )
    for field_name in _STAGE_FIELD_OWNERSHIP[1]:
        value = getattr(stage1, field_name)
        if value is not None and value != []:
            setattr(merged, field_name, value)
    for field_name in _STAGE_FIELD_OWNERSHIP[2]:
        value = getattr(stage2, field_name)
        if value is not None and value != []:
            setattr(merged, field_name, value)
    for field_name in _STAGE_FIELD_OWNERSHIP[3]:
        value = getattr(stage3, field_name)
        if value is not None and value != []:
            setattr(merged, field_name, value)
    merged = ShippingInstruction.model_validate(merged.model_dump())
    assert merged.parties == stage1.parties, "Birlesik parties, stage1'den farkli"
    assert merged.transport_plans == stage2.transport_plans, (
        "Birlesik transport_plans, stage2'den farkli"
    )
    assert merged.equipment_list == stage3.equipment_list, (
        "Birlesik equipment_list, stage3'ten farkli"
    )
    assert merged.cargo_items == stage3.cargo_items, (
        "Birlesik cargo_items, stage3'ten farkli"
    )
    return merged


def run_threestage_extraction(
    upper_text: str,
    middle_text: str,
    lower_text: str,
    document_language: str = "en",
    output_language: str = "en",
) -> Tuple[ShippingInstruction, Dict[int, str]]:
    assert upper_text.strip() or middle_text.strip() or lower_text.strip(), (
        "Tum bolge metinleri bos"
    )
    raw_outputs: Dict[int, str] = {}
    stage1_instruction, stage1_raw = run_stage_inference(
        upper_text if upper_text.strip() else middle_text,
        1, document_language, output_language,
    )
    raw_outputs[1] = stage1_raw
    stage1_normalized = normalize_extracted_instruction(stage1_instruction, upper_text)
    stage2_instruction, stage2_raw = run_stage_inference(
        middle_text if middle_text.strip() else lower_text,
        2, document_language, output_language,
    )
    raw_outputs[2] = stage2_raw
    stage2_normalized = normalize_extracted_instruction(stage2_instruction, middle_text)
    combined_middle_lower = (
        (middle_text + "\n" + lower_text) if (middle_text.strip() and lower_text.strip())
        else (middle_text or lower_text)
    )
    stage3_instruction, stage3_raw = run_stage_inference(
        combined_middle_lower if combined_middle_lower.strip() else lower_text,
        3, document_language, output_language,
    )
    raw_outputs[3] = stage3_raw
    stage3_normalized = normalize_extracted_instruction(stage3_instruction, combined_middle_lower)
    merged = merge_stage_results(
        stage1_normalized, stage2_normalized, stage3_normalized
    )
    for stage_num, raw in raw_outputs.items():
        assert raw.strip(), f"Asama {stage_num} ham cikti bos"
    return merged, raw_outputs


def build_prompt(
    ocr_text: str,
    document_language: str = "en",
    output_language: str = "en",
) -> str:
    schema = get_json_schema()
    schema_str = json.dumps(schema, indent=2, ensure_ascii=False)
    source_language = _language_names.get(document_language, "English")
    target_language = _language_names.get(output_language, "English")
    prompt = (
        f"System: {_system_prompt}\n\n"
        f"The document language is {source_language}. Interpret OCR labels in that language.\n"
        f"The requested XML content language is {target_language}. Preserve all extracted values in their source "
        "language during this extraction pass. A dedicated translation pass handles descriptive content later. "
        "Never alter proper names, addresses, locations, identifiers, codes, measurement units, or enum values.\n\n"
        f"JSON Schema:\n{schema_str}\n\n"
        f"OCR Text (layout-preserved):\n{ocr_text}\n\n"
        f"Extract the shipping instruction data as JSON:"
    )
    return prompt


def run_guided_inference(
    ocr_text: str,
    document_language: str = "en",
    output_language: str = "en",
) -> str:
    pipe = get_llm_pipeline()
    prompt = build_prompt(ocr_text, document_language, output_language)
    config = _build_generation_config()
    result = pipe.generate(prompt, config)
    return str(result)


def _build_generation_config():
    return _build_generation_config_for_schema(get_json_schema())


def _build_generation_config_for_schema(schema: Dict[str, Any]):
    import openvino_genai

    config = openvino_genai.GenerationConfig()
    config.max_new_tokens = settings.model.max_new_tokens
    config.do_sample = False
    structured_output_mode = _configure_structured_output(
        config,
        openvino_genai,
        json.dumps(schema),
    )
    logger.debug("OpenVINO structured output mode: %s", structured_output_mode)
    return config


def _configure_structured_output(config, openvino_genai, schema_json: str) -> Optional[str]:
    """Use the newest supported OpenVINO JSON constraint without breaking older builds."""
    structured_config_type = getattr(openvino_genai, "StructuredOutputConfig", None)
    if structured_config_type is not None and hasattr(config, "structured_output_config"):
        structured_config = structured_config_type()
        structured_config.json_schema = schema_json
        config.structured_output_config = structured_config
        return "structured_output_config"

    for attribute in ("structured_generation", "guided_decoding", "json_schema"):
        if hasattr(config, attribute):
            setattr(config, attribute, schema_json)
            return attribute
    return None


def parse_llm_output(raw_output: str) -> ShippingInstruction:
    cleaned = _extract_json(raw_output)
    data = json.loads(cleaned)
    return ShippingInstruction.model_validate(data)


def _extract_labeled_value(ocr_text: str, patterns: tuple[str, ...]) -> Optional[str]:
    for pattern in patterns:
        match = re.search(pattern, ocr_text)
        if match:
            value = match.group("value").strip().rstrip(".")
            if value:
                return value
    return None


def _normalize_date_value(value: str, require_time: bool = False) -> Optional[str]:
    match = re.fullmatch(
        r"\s*(\d{1,4})[./-](\d{1,2})[./-](\d{1,4})(?:[T\s]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?\s*",
        value,
    )
    if not match:
        return None
    first, second, third, hour, minute, second_value = match.groups()
    if len(first) == 4:
        year, month, day = int(first), int(second), int(third)
    elif len(third) == 4:
        day, month, year = int(first), int(second), int(third)
    else:
        return None
    if require_time and hour is None:
        return None
    try:
        parsed = datetime(
            year,
            month,
            day,
            int(hour or 0),
            int(minute or 0),
            int(second_value or 0),
        )
    except ValueError:
        return None
    if hour is None:
        return parsed.strftime("%Y-%m-%d")
    return parsed.strftime("%Y-%m-%dT%H:%M:%S")


def _extract_labeled_date(
    ocr_text: str,
    patterns: tuple[str, ...],
    require_time: bool = False,
) -> Optional[str]:
    value = _extract_labeled_value(ocr_text, patterns)
    return _normalize_date_value(value, require_time) if value else None


_PORT_PREFIX_PATTERN = re.compile(
    r"^([A-Z]{2,6})\s+(?=[A-Z]{2,})"
)
_KNOWN_PORTS = frozenset({
    "ALIAGA", "ISTANBUL", "IZMIR", "MERSIN", "ANTALYA", "SAMSUN", "TRABZON",
    "KARACHI", "HAMBURG", "ROTTERDAM", "ANTWERP", "SINGAPORE", "SHANGHAI",
    "HONG KONG", "BUSAN", "TOKYO", "NEW YORK", "LOS ANGELES", "MIAMI",
    "RIO DE JANEIRO", "SANTOS", "DUBAI", "JEBEL ALI", "HO CHI MINH",
    "HAI PHONG", "COLOMBO", "CHENNAI", "MUMBAI", "LONDON", "FELIXSTOWE",
    "GENOA", "BARCELONA", "VALENCIA", "PIRAEUS", "GDANSK", "GDYNIA",
})


def _parse_european_number(raw: str) -> Optional[float]:
    if not raw:
        return None
    cleaned = raw.strip().replace(" ", "")
    cleaned = cleaned.replace(".", "")
    cleaned = cleaned.replace(",", ".")
    try:
        return float(cleaned)
    except ValueError:
        return None


def _iso6346_check_digit_light(reference: str) -> bool:
    normalized = re.sub(r"\s+", "", reference or "").upper()
    if not re.fullmatch(r"[A-Z]{4}\d{7}", normalized):
        return False
    letter_values: dict[str, int] = {}
    value = 10
    for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        while value % 11 == 0:
            value += 1
        letter_values[letter] = value
        value += 1
    total = 0
    for position, character in enumerate(normalized[:10]):
        numeric = int(character) if character.isdigit() else letter_values[character]
        total += numeric * (2 ** position)
    calculated = (total % 11) % 10
    return calculated == int(normalized[-1])


def _extract_containers_from_ocr(ocr_text: str) -> list[str]:
    candidates = re.findall(r"\b[A-Z]{4}\d{7}\b", ocr_text)
    valid: list[str] = []
    for candidate in candidates:
        if _iso6346_check_digit_light(candidate):
            valid.append(candidate)
    seen: set[str] = set()
    deduped: list[str] = []
    for container in valid:
        if container not in seen:
            seen.add(container)
            deduped.append(container)
    return deduped


def _clean_location_name(location) -> None:
    if location is None or not location.location_name:
        return
    name = location.location_name.strip()
    if not name:
        return
    match = _PORT_PREFIX_PATTERN.match(name)
    if match:
        remainder = name[match.end():].strip()
        words = remainder.split()
        for i in range(len(words), 0, -1):
            candidate = " ".join(words[:i])
            if candidate.upper() in _KNOWN_PORTS:
                location.location_name = candidate
                return
        if remainder:
            location.location_name = remainder


def normalize_extracted_instruction(
    instruction: ShippingInstruction,
    ocr_text: str = "",
) -> ShippingInstruction:
    normalized = instruction.model_copy(deep=True)
    if normalized.document_status_code is None:
        normalized.document_status_code = DocumentStatusCode.DRAFT
    if normalized.shipping_instruction_reference is None:
        normalized.shipping_instruction_reference = _extract_labeled_value(
            ocr_text,
            (
                r"(?im)^\s*shipping\s+instructions?(?:\s+(?:reference|ref|number|no\.?))?\s*[:#-]?\s*(?P<value>[A-Z0-9][A-Z0-9._/-]{2,})\s*$",
                r"(?im)^\s*(?:s\s*/\s*i|si)\s+(?:reference|ref|number|no\.?)\s*[:#-]?\s*(?P<value>[A-Z0-9][A-Z0-9._/-]{2,})\s*$",
                r"(?im)^\s*(?:sevkiyat\s+)?talimat[ıi]\s+(?:referans[ıi]|numaras[ıi]|no\.?)\s*[:#-]?\s*(?P<value>[A-Z0-9][A-Z0-9._/-]{2,})\s*$",
            ),
        )
    if normalized.carrier_booking_reference is None:
        normalized.carrier_booking_reference = _extract_labeled_value(
            ocr_text,
            (
                r"(?im)^\s*(?:carrier\s+)?booking\s*(?:reference|ref|number|no\.?)?\s*[:#-]\s*(?P<value>[A-Z0-9][A-Z0-9._/-]{2,})\s*$",
                r"(?im)^\s*bkg\s*(?:reference|ref|number|no\.?)?\s*[:#-]\s*(?P<value>[A-Z0-9][A-Z0-9._/-]{2,})\s*$",
                r"(?im)^\s*rezervasyon\s*(?:referans[ıi]|numaras[ıi]|no\.?)?\s*[:#-]\s*(?P<value>[A-Z0-9][A-Z0-9._/-]{2,})\s*$",
            ),
        )
    if normalized.shipping_instruction_date_time is None:
        normalized.shipping_instruction_date_time = _extract_labeled_date(
            ocr_text,
            (
                r"(?im)^\s*shipping\s+instructions?\s+(?:date\s*/\s*time|date\s+time|datetime)\s*[:#-]\s*(?P<value>\d{1,4}[./-]\d{1,2}[./-]\d{1,4}[T\s]+\d{1,2}:\d{2}(?::\d{2})?)\s*$",
                r"(?im)^\s*(?:si|talimat)\s+(?:date\s*/\s*time|date\s+time|datetime|tarih\s*/\s*saat)\s*[:#-]\s*(?P<value>\d{1,4}[./-]\d{1,2}[./-]\d{1,4}[T\s]+\d{1,2}:\d{2}(?::\d{2})?)\s*$",
            ),
            require_time=True,
        )
    if normalized.issue_date is None:
        normalized.issue_date = _extract_labeled_date(
            ocr_text,
            (
                r"(?im)^\s*(?:issue\s+date|date\s+of\s+issue|date|tarih|d[üu]zenleme\s+tarihi)\s*[:#-]\s*(?P<value>\d{1,4}[./-]\d{1,2}[./-]\d{1,4})\s*$",
            ),
        )
    normalized_instruction_date_time = (
        _normalize_date_value(
            normalized.shipping_instruction_date_time,
            require_time=True,
        )
        if normalized.shipping_instruction_date_time
        else None
    )
    if normalized_instruction_date_time:
        normalized.shipping_instruction_date_time = normalized_instruction_date_time
    normalized_issue_date = (
        _normalize_date_value(normalized.issue_date)
        if normalized.issue_date
        else None
    )
    if normalized_issue_date:
        normalized.issue_date = normalized_issue_date
    for party in normalized.parties:
        if (
            party.party_id
            and party.party_name
            and party.party_id.strip().casefold() == party.party_name.strip().casefold()
        ):
            party.party_id = None
    tax_office = _extract_labeled_value(
        ocr_text,
        (
            r"(?im)^\s*(?:v\.?\s*dairesi|vergi\s+dairesi|tax\s+office)\s*[:#-]\s*(?P<value>[^\r\n]+?)\s*$",
        ),
    )
    place_name = (
        normalized.place_of_issue.location_name
        if normalized.place_of_issue is not None
        else None
    )
    if tax_office and place_name:
        normalized_tax_office = re.sub(r"\W+", "", tax_office.casefold())
        normalized_place_name = re.sub(r"\W+", "", place_name.casefold())
        if normalized_tax_office == normalized_place_name:
            normalized.place_of_issue = None
    for cargo_item in normalized.cargo_items:
        if cargo_item.description_of_goods:
            cleaned_description = re.sub(
                r"(?i)^\s*(?:\d+\s+)?(?:pallets?|cartons?|boxes?|crates?|bales?|drums?)\s+",
                "",
                cargo_item.description_of_goods,
            ).strip()
            if cleaned_description:
                cargo_item.description_of_goods = cleaned_description
    date_match = re.search(
        r"(?im)^\s*(?:issue\s+date|date|tarih)\s*[:\-]\s*(\d{4}-\d{2}-\d{2})\s*$",
        ocr_text,
    )
    date_time_value = normalized.shipping_instruction_date_time
    if (
        date_match
        and date_time_value
        and re.fullmatch(r"\d{4}-\d{2}-\d{2}", date_time_value.strip())
        and date_time_value.strip() == date_match.group(1)
        and normalized.issue_date in {None, date_match.group(1)}
    ):
        normalized.issue_date = date_match.group(1)
        normalized.shipping_instruction_date_time = None
    for party in normalized.parties:
        contact = party.contact_details
        if contact and contact.name:
            name_val = contact.name.strip()
            if re.match(r"(?i)^(?:tel|telefon|telephone)[\s:.\-]+\d", name_val):
                phone_part = re.sub(r"(?i)^(?:tel|telefon|telephone)[\s:.\-]+", "", name_val)
                if phone_part.isdigit() and not contact.phone_number:
                    contact.phone_number = phone_part
                contact.name = None
            elif re.fullmatch(r"[\d\s\-()+./]+", name_val):
                if not contact.phone_number:
                    contact.phone_number = name_val
                contact.name = None
    for plan in normalized.transport_plans:
        _clean_location_name(plan.port_of_loading)
        _clean_location_name(plan.port_of_discharge)
        _clean_location_name(plan.place_of_receipt)
        _clean_location_name(plan.place_of_delivery)
    brut_value = _extract_labeled_value(
        ocr_text,
        (
            r"(?im)(?:BRUT|GROSS\s+WEIGHT|GROSS|G\.W\.|GW)\s*[:#\-]?\s*(?:WEIGHT|AGIRLIK|WT\.?)?\s*[:#\-]?\s*(?P<value>[\d]{1,3}(?:\.[\d]{3})*(?:,[\d]+)?)",
        ),
    )
    net_value = _extract_labeled_value(
        ocr_text,
        (
            r"(?im)(?:NET|NET\s+WEIGHT|N\.W\.|NW)\s*[:#\-]?\s*(?:WEIGHT|AGIRLIK|WT\.?)?\s*[:#\-]?\s*(?P<value>[\d]{1,3}(?:\.[\d]{3})*(?:,[\d]+)?)",
        ),
    )
    if brut_value is not None:
        parsed_brut = _parse_european_number(brut_value)
        if parsed_brut is not None and parsed_brut > 0:
            from app.models import Weight, WeightUnit
            applied = False
            for equipment in normalized.equipment_list:
                if equipment.cargo_gross_weight is None or equipment.cargo_gross_weight.weight is None:
                    equipment.cargo_gross_weight = Weight(weight=parsed_brut, unit=WeightUnit.KILOGRAM)
                    applied = True
                    break
            if not applied:
                from app.models import Equipment
                new_eq = Equipment(cargo_gross_weight=Weight(weight=parsed_brut, unit=WeightUnit.KILOGRAM))
                normalized.equipment_list.append(new_eq)
    if net_value is not None:
        parsed_net = _parse_european_number(net_value)
        if parsed_net is not None and parsed_net > 0:
            from app.models import CargoWeight
            applied = False
            for cargo_item in normalized.cargo_items:
                if cargo_item.weight is None or cargo_item.weight.weight_value is None:
                    cargo_item.weight = CargoWeight(weight_value=parsed_net, unit="KGM")
                    applied = True
                    break
            if not applied:
                from app.models import CargoItem
                new_item = CargoItem(weight=CargoWeight(weight_value=parsed_net, unit="KGM"))
                normalized.cargo_items.append(new_item)
    ocr_containers = _extract_containers_from_ocr(ocr_text)
    if ocr_containers:
        existing_refs: set[str] = set()
        for equipment in normalized.equipment_list:
            if equipment.equipment_reference:
                existing_refs.add(re.sub(r"\s+", "", equipment.equipment_reference).upper())
        for container_ref in ocr_containers:
            if container_ref not in existing_refs:
                from app.models import Equipment
                normalized.equipment_list.append(Equipment(equipment_reference=container_ref))
    return normalized


def _extract_json(text: str) -> str:
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise ValueError("No JSON object found in LLM output")
    return text[start:end+1]


def _repair_json(text: str) -> str:
    text = re.sub(r",\s*([}\]])", r"\1", text)
    text = re.sub(r"([{,])\s*'([^']*)'\s*:", r'\1"\2":', text)
    return text


def _parse_json_with_fallback(text: str) -> Dict[str, Any]:
    repaired = _repair_json(text)
    try:
        data = json.loads(repaired)
    except json.JSONDecodeError:
        data = ast.literal_eval(text)
    if not isinstance(data, dict):
        raise ValueError("LLM output must contain a JSON object")
    return data


def run_inference_with_fallback(
    ocr_text: str,
    document_language: str = "en",
    output_language: str = "en",
    segmented_ocr: Optional[Tuple[str, str, str]] = None,
) -> Tuple[ShippingInstruction, str]:
    if segmented_ocr is not None:
        upper_text, middle_text, lower_text = segmented_ocr
        merged, raw_outputs = run_threestage_extraction(
            upper_text, middle_text, lower_text,
            document_language, output_language,
        )
        combined_raw = json.dumps(
            {str(k): v for k, v in raw_outputs.items()},
            ensure_ascii=False,
        )
        return merged, combined_raw
    raw_output = run_guided_inference(ocr_text, document_language, output_language)
    try:
        return normalize_extracted_instruction(
            parse_llm_output(raw_output),
            ocr_text,
        ), raw_output
    except Exception:
        cleaned = _extract_json(raw_output)
        data = _parse_json_with_fallback(cleaned)
        return normalize_extracted_instruction(
            ShippingInstruction.model_validate(data),
            ocr_text,
        ), raw_output


def _extract_targeted_ocr_excerpt(
    ocr_text: str, findings: list[dict[str, Any]], context_lines: int = 3
) -> str:
    """Extract only OCR lines relevant to the findings, not the full text."""
    if not findings:
        return ocr_text

    # Keywords associated with common field paths
    keyword_map = {
        "shipper": ("shipper", "exporter", "seller", "gönderici", "ihracatçı"),
        "consignee": ("consignee", "buyer", "receiver", "alıcı", "ithalatçı"),
        "party": ("party", "shipper", "consignee", "notify"),
        "port_of_loading": ("port of loading", "loading", "pol", "yükleme"),
        "port_of_discharge": ("port of discharge", "discharge", "pod", "boşaltma"),
        "equipment": ("container", "equipment", "seal", "konteyner"),
        "weight": ("weight", "gross", "kg", "kgs", "kgm", "ağırlık"),
        "cargo": ("cargo", "goods", "description", "package", "mal"),
        "reference": ("reference", "booking", "no", "number", "referans"),
        "date": ("date", "issue", "tarih"),
        "vessel": ("vessel", "voyage", "imo", "ship", "gemi"),
    }

    terms: set[str] = set()
    for finding in findings:
        path = finding.get("field_path", "").casefold()
        for key, keywords in keyword_map.items():
            if key in path:
                terms.update(keywords)

    if not terms:
        return ocr_text

    lines = ocr_text.splitlines()
    matched_indices: set[int] = set()
    for i, line in enumerate(lines):
        lowered = line.casefold()
        if any(term in lowered for term in terms):
            for offset in range(-context_lines, context_lines + 1):
                idx = i + offset
                if 0 <= idx < len(lines):
                    matched_indices.add(idx)

    if not matched_indices:
        return ocr_text

    selected = [lines[i] for i in sorted(matched_indices)]
    return "\n".join(selected)


def build_refinement_prompt(
    ocr_text: str,
    initial_result: ShippingInstruction,
    findings: list[dict[str, Any]],
    document_language: str,
) -> str:
    source_language = _language_names.get(document_language, "mixed Turkish and English")
    schema = json.dumps(get_json_schema(), ensure_ascii=False)
    initial_json = initial_result.model_dump_json(exclude_none=False)
    findings_json = json.dumps(findings, ensure_ascii=False)

    # Use targeted OCR excerpt to reduce token usage
    targeted_ocr = _extract_targeted_ocr_excerpt(ocr_text, findings)
    if len(targeted_ocr) * 4 > len(ocr_text) * 3:
        # Targeted excerpt isn't significantly smaller; use full text
        targeted_ocr = ocr_text

    return (
        f"System: {_system_prompt}\n\n"
        f"The source is {source_language}. Recheck the initial extraction against the OCR text. "
        "Correct only values directly supported by the OCR text. Resolve the listed deterministic validation "
        "findings when the document contains the required evidence. Keep unsupported fields null and preserve "
        "identifiers, names, addresses, locations, codes, units, and numeric values exactly.\n\n"
        f"Validation findings:\n{findings_json}\n\n"
        f"Initial extraction:\n{initial_json}\n\n"
        f"JSON Schema:\n{schema}\n\n"
        f"OCR Text:\n{targeted_ocr}\n\n"
        "Return the verified shipping instruction as JSON:"
    )


def run_refinement_with_fallback(
    ocr_text: str,
    initial_result: ShippingInstruction,
    findings: list[dict[str, Any]],
    document_language: str,
) -> Tuple[ShippingInstruction, str]:
    pipe = get_llm_pipeline()
    prompt = build_refinement_prompt(
        ocr_text,
        initial_result,
        findings,
        document_language,
    )
    raw_output = str(pipe.generate(prompt, _build_generation_config()))
    try:
        return normalize_extracted_instruction(
            parse_llm_output(raw_output),
            ocr_text,
        ), raw_output
    except Exception:
        cleaned = _extract_json(raw_output)
        data = _parse_json_with_fallback(cleaned)
        return normalize_extracted_instruction(
            ShippingInstruction.model_validate(data),
            ocr_text,
        ), raw_output
